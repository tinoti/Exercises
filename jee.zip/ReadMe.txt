1. Instalirati node.
https://nodejs.org/dist/v12.19.0/node-v12.19.0-x64.msi   (Ostavi defaultnu putanju i obavezno stisnuti "Add to Path" Checkbox)

2. Instalirati VS Code (ako nemas)
https://code.visualstudio.com/ (Ovo je svejedno gdje instaliras)

3. Extractas zip koji sam ti poslao i pokrenes VS Code, u gornjem lijevom kutu imas tab File, stisnes to i onda new folder. Otvorit ce ti window da odaberes lokaciju, bitno je da odaberes gopnd folder i unutar njega folder src.

4. Instalirati dependencie. Za to trebas otvoriti terminal, najlakse ti je sa shortcutom, drzis ctrl i stisnes onaj gumb iznad Tab-a na tastaturi.
Kad ti se otvori, upises: "npm install", povuci ce ti sve automatski. Kada zavrsi upises drugu komandu: "npm install -g serve". 
Kada zavrsi druga komanda, upises u terminal "serve" (komande se upisuju bez navodnika). Terminal ce ti onda izbaciti poruku "Serving!" i dati še ti 2 adrese, drzis ctrl i stisnes na adresu.


