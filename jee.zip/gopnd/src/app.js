var app = angular.module("MyApp", [
  //"ngAnimate",
  "ui.router",
  "ui.bootstrap",
  "oc.lazyLoad",
  "MyApp.config"
]);

var version = "20200120";

app.run([
  "$rootScope","$locale",
  function ($rootScope, $locale) {
    $locale.NUMBER_FORMATS.GROUP_SEP = ".";
    $locale.NUMBER_FORMATS.DECIMAL_SEP = ",";
    $rootScope.version = version;
    $rootScope.isSocked = false;    
  }])

app.config(["$stateProvider", "$urlRouterProvider", "$httpProvider", "CONFIG_CONSTANTS",
  function ($stateProvider, $urlRouterProvider, $httpProvider, CONFIG_CONSTANTS) {

    $stateProvider
      .state("app", {
        abstract: true,
        url: "/app",
        templateUrl: "template/app.html",
      })
      .state("app.home", {
        url: "/home",
        templateUrl: "view/home.html",
        resolve: {
          deps: ["$ocLazyLoad", function ($ocLazyLoad) {
            return $ocLazyLoad.load([
              "lazy-home", "lazy-home-css"
            ], { serie: true })
              .then(function () { });
          }],
        }
      })
     

    if (!$httpProvider.defaults.headers.get) {
      $httpProvider.defaults.headers.get = {};
    }
    //disable IE ajax request caching
    //$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
    //$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    //$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';

    $urlRouterProvider.otherwise("/app/home");
    //$httpProvider.interceptors.push("httpInterceptor");
  }
])