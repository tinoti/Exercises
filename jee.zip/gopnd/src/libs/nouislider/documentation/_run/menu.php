<div class="bar-group">
	<a class="bar-link project" href="/nouislider/">noUiSlider</a>
	<a class="bar-link" href="/nouislider/slider-values/">Slider range and handles</a>
	<a class="bar-link" href="/nouislider/slider-read-write/">Reading &amp; Setting values</a>
	<a class="bar-link" href="/nouislider/slider-options/">Options</a>
	<a class="bar-link" href="/nouislider/behaviour-option/">Tapping, dragging &amp; fixed ranges</a>
	<a class="bar-link" href="/nouislider/examples/">Examples</a>
	<a class="bar-link" href="/nouislider/events-callbacks/">Events</a>
	<a class="bar-link" href="/nouislider/pips/">Scale/Pips</a>
	<a class="bar-link" href="/nouislider/more/">More...</a>
	<a class="bar-link download" href="/nouislider/download/">Download noUiSlider</a>
</div>
