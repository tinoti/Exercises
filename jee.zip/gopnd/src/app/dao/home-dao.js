"use strict";

angular.module("MyApp").factory("HomeDao",
   function ($http, $q) {

   	var service = {};

    	
	service.readJson = function (fname, path) {

        var deferred = $q.defer();

        /*$http.get(path+fname)
            .then(function (data) {
                deferred.resolve(data);
            }, function (error) {
                MainUtil.printErrorToLog(error);
                deferred.reject();
            });*/

        var timestamp = (new Date).getTime();

        $http({
			method: 'GET',
			url: path+fname+"?t="+timestamp
		}).success(function (data, status, headers, config) {
            deferred.resolve(data);
		})
		.error(function (data, status, headers, config) {
			deferred.reject(data);
		});


        return deferred.promise;
    };
    
    return service;

});