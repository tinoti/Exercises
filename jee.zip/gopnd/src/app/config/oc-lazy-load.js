"use strict";

var version = "?v=20200206";

app.config(["$ocLazyLoadProvider", function ($ocLazyLoadProvider) {
	$ocLazyLoadProvider.config({
		debug: false,
		events: false,
		modules: [
			{
				name: "lazy-home",
				files: [
					"js/byrushan/chosen.js",
					"js/byrushan/chosen.jquery.js",
					"app/controller/home-ctrl.js"+version,
					"app/dao/home-dao.js"+version
				]
			},{
				name: "lazy-home-css",
				insertBefore: "[href='libs/animate.css/animate.min.css']",
				files: [
					"css/byrushan/chosen.min.css"
				]
			}
		]
	})
}]);