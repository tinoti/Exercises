angular.module("MyApp.config", [])
.constant("CONFIG_CONSTANTS", {"TOKEN_NAME":"app-token","GATEWAY_CONTEXT_ROOT":"http://localhost:3030", "SOCKET_URL":"http://localhost:3040", "SOCKET_PATH": "/socket/socket.io", "JWT_URL":"http://jwt-servis-kolaboracija-razvoj.osapps.test.gzaop.local/getJWT/bero/mkatic","LOGOUT_URL":"/pkmslogout"});
