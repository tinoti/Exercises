app
    .directive("validateOdbitak", function () {
        return {
            restrict: "A",
            require: "ngModel",
            link: function (scope, element, attr, ngModel, ctrl) {
                ngModel.$validators.lessOdbitak = function (val) {
                    if(scope.sifarnik.godine) {
                        if (val != null || val != undefined) {
                            val = val.replace(".", "").replace(",", ".")
                            if (val < scope.sifarnik.godine[scope.osnovno.comboYear].minGodisnjiOdbitak) {
                                return false;
                            }
                            else {
                                return true;
                            }
                        }
                    }
                    return true;
                };
            }
        }
    })