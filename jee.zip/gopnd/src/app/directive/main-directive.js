app

	/**
     * Plavi slide kod input polja
     */
	.directive('fgLine', function () {
		return {
			restrict: 'C',
			link: function (scope, element) {
				if ($('.fg-line')[0]) {
					$('body').on('focus', '.form-control', function () {
						$(this).closest('.fg-line').addClass('fg-toggled');
					})

					$('body').on('blur', '.form-control', function () {
						var p = $(this).closest('.form-group');
						var i = p.find('.form-control').val();

						if (p.hasClass('fg-float')) {
							if (i.length == 0) {
								$(this).closest('.fg-line').removeClass('fg-toggled');
							}
						}
						else {
							$(this).closest('.fg-line').removeClass('fg-toggled');
						}
					});
				}

			}
		}

	})

	/**
     * Za mask unutar input polja
     */
	.directive('inputMask', function () {
		return {
			restrict: 'A',
			scope: {
				inputMask: '='
			},
			link: function (scope, element) {
				element.mask(scope.inputMask.mask);
			}
		}
	})

    /**
     * ?
     */
	.directive("stopPropagate", function () {
		return {
			restrict: "C",
			link: function (scope, element) {
				element.on("click", function (event) {
					event.stopPropagation();
				});
			}
		}
	})

	.directive("aPrevent", function () {
		return {
			restrict: "C",
			link: function (scope, element) {
				element.on("click", function (event) {
					event.preventDefault();
				});
			}
		}
	})

    /**
     * ?
     */
	.directive("print", function () {
		return {
			restrict: "A",
			link: function (scope, element) {
				element.click(function () {
					window.print();
				})
			}
		}
	})

	// =========================================================================
	// PLACEHOLDER FOR IE 9 (on .form-control class)
	// =========================================================================
	.directive('formControl', function () {
		return {
			restrict: 'C',
			link: function (scope, element, attrs) {
				if (angular.element('html').hasClass('ie9')) {
					$('input, textarea').placeholder({
						customClass: 'ie9-placeholder'
					});
				}
			}

		}
	})