"use strict";

app.controller("AppCtrl", [
	"$scope",
	function ($scope) {

	// Detact Mobile Browser
	if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
		angular.element("html").addClass("ismobile");
	}

	$scope.setClick = function() {
		// bez toga ne radi dobro promjena clase
	}

	$scope.getClassForSelectedFontSize = function(el) {
		var fontSize1 = document.getElementById('widgetMainId').classList.contains("widget-fs-1");
		var fontSize2 = document.getElementById('widgetMainId').classList.contains("widget-fs-2");
		var fontSize3 = document.getElementById('widgetMainId').classList.contains("widget-fs-3");
		var fontSize4 = document.getElementById('widgetMainId').classList.contains("widget-fs-4");

		if (el=="main-left") {
			return fontSize3 ? "col-md-12" : (fontSize4) ? "col-lg-12" : "col-lg-5 col-md-6 col-sm-12";
		}
		else if (el=="main-right") {
			return fontSize3 ? "col-md-12" : (fontSize4) ? "col-lg-12" : "col-lg-7 col-md-6 col-sm-12";
		}
		else if (el=="sub") {
			return (fontSize1 || fontSize2 || fontSize3 || fontSize4) ? "" : "col-lg-6";
		}
	}
}]);