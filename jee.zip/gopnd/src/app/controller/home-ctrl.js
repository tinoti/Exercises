angular.module("MyApp").controller("HomeCtrl", [
	"$scope", "HomeDao", "$uibModal",
	function ($scope, HomeDao, $uibModal) {

		$scope.osnovno = {};
		$scope.osnovno.mjesecnaNeoporezivaOsnovica = new Array(12);
		$scope.osnovno.comboYear = {};
		$scope.osnovno.kategorija = {};
		$scope.sifarnik = {};
		$scope.izracun = {
			porez1Iznos: 0,
			porez2Iznos: 0,
			prirezIznos: 0,
			porezPrirezIznos: 0,
			razlika: 0,
			prikaz: false
		};
		$scope.pattern = {
			valuta: /(^[0-9]{1,12}$)|(^[0-9]{1,12},[0-9]{0,2}$)|(^[0-9]{1,3}([.][0-9]{3})*$)|(^([0-9]{1,3})([.][0-9]{3})*,[0-9]{1,2}$)/,
			posto: /(^[0-9]{1,2}$)|(^100$)/
		};
		$scope.maxlength = {
			posto: "3",
			koeficijent: "5",
			novac: "20"
		};
		$scope.tableCheckbox = false;

		HomeDao.readJson("podaci.json", "/json/").then(
			function (returnData) {
				$scope.sifarnik = returnData;
				$scope.osnovno.comboYear = $scope.sifarnik.zajednicko.comboOdabirGodina[0].CODE;
			},
			function (error) { }
		);

		$scope.comboGodinaChanged = function () {
			if ($scope.sifarnik.godine[$scope.osnovno.comboYear].prikazKategorija == true) {
				var last = $scope.sifarnik.godine[$scope.osnovno.comboYear].kategorija.length - 1;
				$scope.osnovno.kategorija = $scope.sifarnik.godine[$scope.osnovno.comboYear].kategorija[last].CODE;
			}
			if ($scope.osnovno.osobniOdbitak < $scope.sifarnik.godine[$scope.osnovno.comboYear].minGodisnjiOdbitak) {
				$scope.osnovno.osobniOdbitak = ""
			}
		}

		$scope.openModal = function () {
			$scope.modalInstance = $uibModal.open({
				templateUrl: "./view/primjer-mladi-modal.html",
				size: "lg",
				windowClass: "mladiModalOptions",
				controller: function ($scope, $uibModalInstance) {
					$scope.closeModal = function () {
						$uibModalInstance.close();
					}
				}
			});
		}

		$scope.onBtnRacunaj = function () {
			racunaj();
		}
		$scope.disableButton = function () {
			if (isUndefinedNullBlank($scope.osnovno.brutoIsplaceno) ||
			isUndefinedNullBlank($scope.osnovno.doprinosUplaceno) ||
			isUndefinedNullBlank($scope.osnovno.porezPrirezUplaceno) ||
			isUndefinedNullBlank($scope.osnovno.osobniOdbitak)) {
			return true
		}

			return false
		}
		$scope.clearOsobniOdbitak = function (checked) {
			if (checked == true) {
				$scope.osnovno.osobniOdbitak = angular.copy($scope.sifarnik.godine[$scope.osnovno.comboYear].minGodisnjiOdbitak) + "";
			}
		}
		$scope.racunajOsobniOdbitak = function () {
			var osobniOdbitak = $scope.sifarnik.godine[$scope.osnovno.comboYear].minMjesecniOdbitak * 12;

			for (i = 0; i < 12; i++) {
				var data = $scope.osnovno.mjesecnaNeoporezivaOsnovica[i];
				var dataKoef = (isUndefinedNullBlank(data) || isUndefinedNullBlank(data.koef)) ? 0 : replaceChar($scope.osnovno.mjesecnaNeoporezivaOsnovica[i].koef);
				var dataPosto = (isUndefinedNullBlank(data) || isUndefinedNullBlank(data.posto)) ? 0 : replaceChar($scope.osnovno.mjesecnaNeoporezivaOsnovica[i].posto);

				osobniOdbitak += (dataKoef * dataPosto * $scope.sifarnik.godine[$scope.osnovno.comboYear].minMjesecniOdbitakZaKoef / 100);
			}
			$scope.osnovno.osobniOdbitak = angular.copy(osobniOdbitak) + "";
		}

		function racunaj() {

			var brutoIsplaceno = replaceChar($scope.osnovno.brutoIsplaceno);
			var doprinosUplaceno = replaceChar($scope.osnovno.doprinosUplaceno);
			var osobniOdbitak = replaceChar($scope.osnovno.osobniOdbitak);
			var porezPrirezUplaceno = replaceChar($scope.osnovno.porezPrirezUplaceno);
			var prirezGodisnjaStopa = $scope.osnovno.prirezGodisnjaStopa ? $scope.osnovno.prirezGodisnjaStopa : 0;

			var porezPrirezOsnovica = (brutoIsplaceno - doprinosUplaceno - osobniOdbitak);

			var porezniRazred1 = porezPrirezOsnovica;
			var porezniRazred2 = 0;

			if (porezPrirezOsnovica > $scope.sifarnik.godine[$scope.osnovno.comboYear].porezniRazred1Max) {
				porezniRazred1 = $scope.sifarnik.godine[$scope.osnovno.comboYear].porezniRazred1Max;
				porezniRazred2 = porezPrirezOsnovica - $scope.sifarnik.godine[$scope.osnovno.comboYear].porezniRazred1Max;
			}
			else if (porezPrirezOsnovica < 0) {
				porezniRazred1 = 0;
			}

			porezniRazred1 = porezniRazred1 * $scope.sifarnik.godine[$scope.osnovno.comboYear].porezniRazredPostotak1;
			porezniRazred2 = porezniRazred2 * $scope.sifarnik.godine[$scope.osnovno.comboYear].porezniRazredPostotak2;

			
			var prirezTrebaBitiUplaceno = (porezniRazred1 + porezniRazred2) * prirezGodisnjaStopa;
			var porezPrirezTrebaBitiUplaceno = porezniRazred1 + porezniRazred2 + prirezTrebaBitiUplaceno;
			var povrat = porezPrirezUplaceno - porezPrirezTrebaBitiUplaceno;

			if($scope.sifarnik.godine[$scope.osnovno.comboYear].prikazKategorija) {
				var postotak = $scope.sifarnik.godine[$scope.osnovno.comboYear].kategorija[$scope.osnovno.kategorija-1].postotak
				var prirezTrebaBitiUplacenoMladi = (porezniRazred1 * postotak + porezniRazred2) * prirezGodisnjaStopa
				var porezPrirezTrebaBitiUplacenoMladi = porezniRazred1 * postotak + porezniRazred2 + prirezTrebaBitiUplacenoMladi;
				povrat = porezPrirezUplaceno - porezPrirezTrebaBitiUplacenoMladi;
			}			

			$scope.izracun.porez1Iznos = new BigNumber(porezniRazred1).toFixed(2);
			$scope.izracun.porez2Iznos = new BigNumber(porezniRazred2).toFixed(2);
			$scope.izracun.prirezIznos = new BigNumber(prirezTrebaBitiUplaceno).toFixed(2);
			$scope.izracun.porezPrirezIznos = new BigNumber(porezPrirezTrebaBitiUplaceno).toFixed(2);
			$scope.izracun.razlika = new BigNumber(povrat).toFixed(2);
			$scope.izracun.prikaz = true;
		}

		function isUndefinedNullBlank(obj) {
			if (obj == undefined || obj == null || obj == "") {
				return true;
			}
			return false;
		}
		function replaceChar(val) {
			if (!isUndefinedNullBlank(val)) {
				return val.replace(".", "").replace(",", ".")
			}
			return val;
		}
	}
]);