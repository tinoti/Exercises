"use strict";

app.filter("codeLabelFilter", [function() {
    return function(label, array) {

    	if (array) {
    		array.forEach(function(val, key) {

	    		if (val.CODE == label) {
	                label = val.LABEL;
	            }
	        })
    	}

        return label;
    }
}]);