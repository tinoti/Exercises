﻿/* APIS widget v0.3 */
        var showWidget = false;
        var widgetData = {};
        var widgetMaxLevel = {
           fontSizeMax: 4,
           contrastMax: 1,
           fontFamilyMax: 1,
           linkTextDecorationMax: 2           
        };	   

	    var storageName = "widgetProperty";

        var readStorageData = getItemStorage(storageName);
        if (readStorageData != '') {
            widgetData = {};
            widgetData = JSON.parse(readStorageData);
            if (widgetData.fontSizeLevel > 0) { 
                addWidgetClass("widget-fs-" + widgetData.fontSizeLevel);
                if (widgetData.fontSizeLevel == widgetMaxLevel.fontSizeMax) {
                    document.getElementById("widget-fs-bg").classList.add("widget-optional-disable");
                }                  
            } else {
                document.getElementById("widget-fs-sm").classList.add("widget-optional-disable");
            }

            if (widgetData.contrastLevel > 0) { 
                addWidgetClass("widget-sc-" + widgetData.contrastLevel); 
            }
            if (widgetData.fontFamilyLevel > 0) { 
                addWidgetClass("widget-ff-" + widgetData.fontFamilyLevel); 
            }
            if (widgetData.linkTextDecorationLevel > 0) { 
                addWidgetClass("widget-ltd-" + widgetData.linkTextDecorationLevel); 
            }
        }
        else {
            setInitialWidgetData()
        }

        function setInitialWidgetData () {
            widgetData = {
                fontSizeLevel: 0,
                contrastLevel: 0,
                fontFamilyLevel: 0,
                linkTextDecorationLevel: 0
            };
            document.getElementById("widget-fs-sm").classList.add("widget-optional-disable");
            document.getElementById("widget-fs-bg").classList.remove("widget-optional-disable");
            setItemStorage(storageName, widgetData);
        }
        function resetWidgetValues() {
            removeWidgetClass("widget-fs-" + widgetData.fontSizeLevel);
            removeWidgetClass("widget-sc-" + widgetData.contrastLevel);
            removeWidgetClass("widget-ff-" + widgetData.fontFamilyLevel);
            removeWidgetClass("widget-ltd-" + widgetData.linkTextDecorationLevel);

            setInitialWidgetData();
        }
        function toggleWidget() {
            showWidget = !showWidget;
            if (showWidget) {
                document.getElementById("widget").style.display = "inline-block";
            } else {
                document.getElementById("widget").style.display = "none";
            }
        } 

        function setFontSize(option) {
            if ((option=='-' && widgetData.fontSizeLevel > 0) || 
                (option=='+' && widgetData.fontSizeLevel < widgetMaxLevel.fontSizeMax) ||
                (option==undefined || option==null || option=='')) {

                removeWidgetClass("widget-fs-" + widgetData.fontSizeLevel);

                if (option=='+') {
                    widgetData.fontSizeLevel++;
                    addWidgetClass("widget-fs-" + widgetData.fontSizeLevel);
                } else if (option=='-') {
                    widgetData.fontSizeLevel--;
                    addWidgetClass("widget-fs-" + widgetData.fontSizeLevel);
                } else if (widgetData.fontSizeLevel < widgetMaxLevel.fontSizeMax) {
                    widgetData.fontSizeLevel++;
                    addWidgetClass("widget-fs-" + widgetData.fontSizeLevel);
                } else {
                    widgetData.fontSizeLevel = 0;
                }
                setItemStorage(storageName, widgetData);

                if (widgetData.fontSizeLevel == widgetMaxLevel.fontSizeMax) {
                    document.getElementById("widget-fs-bg").classList.add("widget-optional-disable");
                    document.getElementById("widget-fs-sm").classList.remove("widget-optional-disable");
                }
                else if (widgetData.fontSizeLevel == 0) {
                    document.getElementById("widget-fs-sm").classList.add("widget-optional-disable");
                    document.getElementById("widget-fs-bg").classList.remove("widget-optional-disable");
                }
                else {
                    document.getElementById("widget-fs-bg").classList.remove("widget-optional-disable");
                    document.getElementById("widget-fs-sm").classList.remove("widget-optional-disable");
                }
            }            
        } 
        function setContrast() {
            removeWidgetClass("widget-sc-" + widgetData.contrastLevel);
            if (widgetData.contrastLevel < widgetMaxLevel.contrastMax) {
                widgetData.contrastLevel++;
                addWidgetClass("widget-sc-" + widgetData.contrastLevel);
            } else {
                widgetData.contrastLevel = 0;
            }

            setItemStorage(storageName, widgetData);
        }
        function setFontFamily() {
            removeWidgetClass("widget-ff-" + widgetData.fontFamilyLevel);
            if (widgetData.fontFamilyLevel < widgetMaxLevel.fontFamilyMax) {
                widgetData.fontFamilyLevel++;
                addWidgetClass("widget-ff-" + widgetData.fontFamilyLevel);
            } else {
                widgetData.fontFamilyLevel = 0;
            }

            setItemStorage(storageName, widgetData);
        }
        function setLinkTextDecoration() {
            removeWidgetClass("widget-ltd-" + widgetData.linkTextDecorationLevel);
            if (widgetData.linkTextDecorationLevel < widgetMaxLevel.linkTextDecorationMax) {
                widgetData.linkTextDecorationLevel++;
                addWidgetClass("widget-ltd-" + widgetData.linkTextDecorationLevel);
            } else {
                widgetData.linkTextDecorationLevel = 0;
            }

            setItemStorage(storageName, widgetData);
        }

        function addWidgetClass(theClass) {
            var element = document.getElementById("widgetMainId");
            element.classList.add(theClass);
        }
        function removeWidgetClass(theClass) {
            var element = document.getElementById("widgetMainId");
            element.classList.remove(theClass);
        } 

		
		function setItemStorage (key, value) {
            if (key && value) {
                localStorage.setItem(key, JSON.stringify(value));
            }
        }         
        function getItemStorage (key) {
            if (localStorage.length > 0) {
				var getItem = localStorage.getItem(key);
				if (getItem) {
					return getItem;
				}
			}
			
			return '';
        }         
        function removeItemStorage (key) {
            if (key) {
                localStorage.removeItem(key);
            }
        }         
        function removeAllStorage () {
            localStorage.clear();
        }		